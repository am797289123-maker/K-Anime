const express = require('express');
const multer  = require('multer');
const cors    = require('cors');
const path    = require('path');
const fs      = require('fs');

const app  = express();
const PORT = process.env.PORT || 3000;

const DATA_DIR   = path.join(__dirname, 'data');
const VIDEOS_DIR = path.join(__dirname, 'uploads', 'videos');
const SRT_DIR    = path.join(__dirname, 'uploads', 'srt');
const COVERS_DIR = path.join(__dirname, 'uploads', 'covers');
[DATA_DIR, VIDEOS_DIR, SRT_DIR, COVERS_DIR].forEach(d => fs.mkdirSync(d, { recursive: true }));

const DB_FILE = path.join(DATA_DIR, 'db.json');
function loadDB(){
  try{ if(fs.existsSync(DB_FILE)) return JSON.parse(fs.readFileSync(DB_FILE,'utf8')); }catch(e){}
  return {animes:[],episodes:[],settings:{admin_password:'admin123',app_name:'كـ أنيـمي',app_icon:'🎌',app_color:'#6C63FF',app_desc:'اكتشف أفضل الأنيمي الكوري',announcement:''},nextAnimeId:1,nextEpId:1};
}
function saveDB(db){ fs.writeFileSync(DB_FILE,JSON.stringify(db,null,2),'utf8'); }
function nid(db,k){ const id=db[k]||1; db[k]=id+1; return id; }
function tryDel(p){ try{if(p&&fs.existsSync(p))fs.unlinkSync(p);}catch(e){} }

app.use(cors());
app.use(express.json({limit:'10mb'}));
app.use(express.urlencoded({extended:true}));
app.use('/uploads', express.static(path.join(__dirname,'uploads')));
app.use(express.static(path.join(__dirname,'public')));

const videoStore = multer.diskStorage({
  destination:(req,file,cb)=>cb(null,VIDEOS_DIR),
  filename:(req,file,cb)=>cb(null,`ep_${Date.now()}${path.extname(file.originalname)}`)
});
const upVideo = multer({storage:videoStore}).single('video');
const srtStore = multer.diskStorage({
  destination:(req,file,cb)=>cb(null,SRT_DIR),
  filename:(req,file,cb)=>cb(null,`srt_${Date.now()}${path.extname(file.originalname)}`)
});
const upSrt = multer({storage:srtStore}).single('srt');
const covStore = multer.diskStorage({
  destination:(req,file,cb)=>cb(null,COVERS_DIR),
  filename:(req,file,cb)=>cb(null,`cov_${Date.now()}${path.extname(file.originalname)}`)
});
const upCover = multer({storage:covStore,limits:{fileSize:10*1024*1024}}).single('cover');

function auth(req,res,next){
  const pw=req.headers['x-admin-password']||req.query.adminpw||'';
  if(pw===loadDB().settings.admin_password) return next();
  res.status(401).json({error:'Unauthorized'});
}

app.get('/api/settings',(req,res)=>{ const d=loadDB(),s=Object.assign({},d.settings); delete s.admin_password; res.json(s); });
app.post('/api/settings',auth,(req,res)=>{ const db=loadDB(); ['app_name','app_icon','app_color','app_desc','announcement'].forEach(k=>{if(req.body[k]!==undefined)db.settings[k]=req.body[k];}); saveDB(db); res.json({ok:true}); });
app.post('/api/settings/password',auth,(req,res)=>{ const{newPassword}=req.body; if(!newPassword||newPassword.length<4) return res.status(400).json({error:'كلمة مرور قصيرة'}); const db=loadDB(); db.settings.admin_password=newPassword; saveDB(db); res.json({ok:true}); });
app.post('/api/auth',(req,res)=>{ if(req.body.password===loadDB().settings.admin_password) return res.json({ok:true}); res.status(401).json({error:'خاطئة'}); });

app.get('/api/animes',(req,res)=>res.json(loadDB().animes));
app.post('/api/animes',auth,(req,res)=>{ const db=loadDB(); const id=nid(db,'nextAnimeId'); db.animes.push(Object.assign({id,createdAt:new Date().toISOString()},req.body)); saveDB(db); res.json({id}); });
app.put('/api/animes/:id',auth,(req,res)=>{ const db=loadDB(); const id=parseInt(req.params.id); const i=db.animes.findIndex(a=>a.id===id); if(i===-1) return res.status(404).json({error:'غير موجود'}); db.animes[i]=Object.assign(db.animes[i],req.body,{id}); saveDB(db); res.json({ok:true}); });
app.delete('/api/animes/:id',auth,(req,res)=>{ const db=loadDB(); const id=parseInt(req.params.id); db.episodes.filter(e=>e.animeId===id).forEach(e=>{tryDel(e.videoPath);tryDel(e.srtPath);}); db.animes=db.animes.filter(a=>a.id!==id); db.episodes=db.episodes.filter(e=>e.animeId!==id); saveDB(db); res.json({ok:true}); });
app.post('/api/animes/cover',auth,(req,res)=>{ upCover(req,res,err=>{ if(err) return res.status(500).json({error:err.message}); if(!req.file) return res.status(400).json({error:'لا يوجد ملف'}); res.json({url:`/uploads/covers/${req.file.filename}`}); }); });

app.get('/api/episodes',(req,res)=>{ const db=loadDB(); const{animeId}=req.query; const eps=animeId?db.episodes.filter(e=>e.animeId===parseInt(animeId)):db.episodes; res.json(eps.sort((a,b)=>a.epNum-b.epNum)); });
app.post('/api/episodes/upload',auth,(req,res)=>{ upVideo(req,res,err=>{ if(err) return res.status(500).json({error:'فشل الرفع: '+err.message}); const{animeId,epNum,title,desc,videoUrl}=req.body; if(!animeId||!epNum||!title) return res.status(400).json({error:'بيانات ناقصة'}); const db=loadDB(); const id=nid(db,'nextEpId'); const url=videoUrl||''; const ep={id,animeId:parseInt(animeId),epNum:parseInt(epNum),title,desc:desc||'',videoPath:req.file?req.file.path:'',videoUrl:url,srcType:req.file?'file':(url.includes('youtube')||url.includes('youtu.be')?'youtube':'url'),fileSize:req.file?req.file.size:0,srtPath:'',uploadedAt:new Date().toISOString()}; db.episodes.push(ep); saveDB(db); res.json({id,ok:true}); }); });
app.post('/api/episodes/:id/srt',auth,(req,res)=>{ upSrt(req,res,err=>{ if(err) return res.status(500).json({error:err.message}); if(!req.file) return res.status(400).json({error:'لا يوجد ملف'}); const db=loadDB(); const i=db.episodes.findIndex(e=>e.id===parseInt(req.params.id)); if(i!==-1){db.episodes[i].srtPath=req.file.path;saveDB(db);} res.json({ok:true}); }); });
app.get('/api/episodes/:id/srt',(req,res)=>{ const db=loadDB(); const ep=db.episodes.find(e=>e.id===parseInt(req.params.id)); if(!ep||!ep.srtPath||!fs.existsSync(ep.srtPath)) return res.status(404).json({error:'لا ترجمة'}); res.sendFile(path.resolve(ep.srtPath)); });
app.delete('/api/episodes/:id',auth,(req,res)=>{ const db=loadDB(); const id=parseInt(req.params.id); const ep=db.episodes.find(e=>e.id===id); if(ep){tryDel(ep.videoPath);tryDel(ep.srtPath);} db.episodes=db.episodes.filter(e=>e.id!==id); saveDB(db); res.json({ok:true}); });

app.get('/api/stream/:id',(req,res)=>{ const db=loadDB(); const ep=db.episodes.find(e=>e.id===parseInt(req.params.id)); if(!ep) return res.status(404).json({error:'غير موجود'}); if(ep.srcType!=='file') return res.json({redirect:ep.videoUrl}); const fp=ep.videoPath; if(!fp||!fs.existsSync(fp)) return res.status(404).json({error:'الملف غير موجود على السيرفر'}); const stat=fs.statSync(fp); const size=stat.size; const range=req.headers.range; if(range){ const p=range.replace(/bytes=/,'').split('-'); const s=parseInt(p[0],10); const e=p[1]?parseInt(p[1],10):size-1; const chunk=e-s+1; res.writeHead(206,{'Content-Range':`bytes ${s}-${e}/${size}`,'Accept-Ranges':'bytes','Content-Length':chunk,'Content-Type':'video/mp4'}); fs.createReadStream(fp,{start:s,end:e}).pipe(res); }else{ res.writeHead(200,{'Content-Length':size,'Content-Type':'video/mp4'}); fs.createReadStream(fp).pipe(res); } });

app.get('/api/stats',(req,res)=>{ const db=loadDB(); res.json({animes:db.animes.length,episodes:db.episodes.length,totalSize:db.episodes.reduce((s,e)=>s+(e.fileSize||0),0)}); });

app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));

app.listen(PORT,'0.0.0.0',()=>console.log(`✅ KAnime on port ${PORT}`));
