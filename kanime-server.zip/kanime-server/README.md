# كـ أنيـمي — KAnime Server

سيرفر كامل لتطبيق الأنيمي مع رفع الفيديو والبث المباشر.

## 🚀 رفع على Railway (مجاناً)

### الخطوات:

**1. أنشئ حساب على GitHub**
- اذهب لـ github.com وأنشئ حساب مجاني

**2. ارفع المشروع على GitHub**
```bash
git init
git add .
git commit -m "KAnime Server"
git branch -M main
git remote add origin https://github.com/اسمك/kanime-server.git
git push -u origin main
```

**3. أنشئ مشروع على Railway**
- اذهب لـ railway.app
- سجّل دخول بحساب GitHub
- اضغط "New Project"
- اختر "Deploy from GitHub repo"
- اختر المشروع

**4. Railway سيعطيك رابط مثل:**
```
https://kanime-server-production.up.railway.app
```

**هذا هو رابط تطبيقك! شاركه مع المشاهدين.**

---

## ⚙️ الإعدادات

| الإعداد | القيمة |
|---------|--------|
| كلمة مرور الأدمن الافتراضية | `admin123` |
| المنفذ | يُحدد تلقائياً من Railway |

---

## 📁 هيكل المشروع

```
kanime-server/
├── server.js          # السيرفر الرئيسي
├── package.json       # المكتبات
├── railway.json       # إعدادات Railway
├── public/
│   └── index.html     # واجهة التطبيق
└── uploads/           # يُنشأ تلقائياً
    ├── videos/        # الفيديوهات
    ├── srt/           # ملفات الترجمة
    └── covers/        # صور الغلاف
```

---

## 🎬 مميزات السيرفر

- ✅ رفع فيديو بدون حد للحجم
- ✅ بث الفيديو مع دعم Range (تقديم وإرجاع)
- ✅ حفظ الترجمة SRT مع كل حلقة
- ✅ قاعدة بيانات SQLite دائمة
- ✅ لوحة تحكم الأدمن محمية بكلمة مرور
- ✅ دعم YouTube + روابط MP4 خارجية

---

## 🔧 تشغيل محلي (للاختبار)

```bash
npm install
node server.js
# افتح: http://localhost:3000
```
